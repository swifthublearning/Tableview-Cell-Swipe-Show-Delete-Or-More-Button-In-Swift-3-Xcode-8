//
//  ViewController.swift
//  Swipe Add Two Buttons in TablviewCell
//
//  Created by Abhishek Verma on 25/07/17.
//  Copyright © 2017 Abhishek Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    let data = ["One","Two","Three","Four","Five"]
    
    @IBOutlet weak var tablview1: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tablview1.dequeueReusableCell(withIdentifier: "Cell1", for: indexPath)
        cell.textLabel?.text = data[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let more = UITableViewRowAction(style: .normal, title: "More", handler: { action , indexPath in
                print("More Click SuccessFully")
        })
        let delete = UITableViewRowAction(style: .destructive, title: "Delete", handler: { action , indexPath in
             print("Delete Click SuccessFully")
        })
        return [more,delete]
    }

}

